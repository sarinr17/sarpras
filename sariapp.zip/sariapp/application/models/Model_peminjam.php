<?php
class Model_peminjam extends CI_Model 
{

    public function getAllPeminjam($keyword = null)
    {
        if( $keyword ) {
            $this->db->like('id', $keyword);
            $this->db->or_like('nama', $keyword);
            $this->db->or_like('alamat', $keyword);
            $this->db->or_like('no_hp', $keyword);
            $this->db->or_like('keperluan', $keyword);
        }
        //create view sql siswa dengan join yang ada pada edit
        return $query = $this->db->get('peminjam')->result_array();
    }

    public function Tambahpeminjam()
    {
        $upload_image = $_FILES['image']['name'];
            if($upload_image) {
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '2048';
            $config['upload_path'] = './assets/foto/';

            $this->load->library('upload', $config);

            if($this->upload->do_upload('image')) {
                $foto = $this->upload->data('file_name');
                $data = [
                    "id" => $this->input->post('id', true),
                    "foto" => $foto,
                    "nama" => $this->input->post('nama', true),
                    "alamat" => $this->input->post('alamat', true),
                    "no_hp" => $this->input->post('no_hp', true),
                    "keperluan" => $this->input->post('keperluan', true)
                ];
                
                $this->db->insert('peminjam', $data);
                
                $this->session->set_flashdata('flash', 'Ditambahkan');

            } else {
                $this->session->set_flashdata('error', $this->upload->display_errors());
            }
        }
    }

    public function Ubahpeminjam()
    {
        $upload_image = $_FILES['image']['name'];
            if($upload_image) {
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '2048';
            $config['upload_path'] = './assets/foto/';

            $this->load->library('upload', $config);

            if($this->upload->do_upload('image')) {
                $foto = $this->upload->data('file_name');
                $this->db->set('foto', $foto);
            } else {
                $this->session->set_flashdata('error', $this->upload->display_errors());
            }
        }

        $id = $this->input->post('id', true);
        $nama = $this->input->post('nama', true);
        $alamat = $this->input->post('alamat', true);
        $no_hp = $this->input->post('no_hp', true);
        $barang = $this->input->post('barang', true);
        $keperluan = $this->input->post('keperluan', true);

        $this->db->set('id', $id);
        $this->db->set('nama', $nama);
        $this->db->set('alamat', $alamat);
        $this->db->set('id_barang', $no_hp);
        $this->db->set('alamat', $id_barang);
        $this->db->set('keperluan', $keperluan);

        $this->db->where('id', $id);
        $this->db->update('peminjam');
    }

    public function hapusPeminjam($id)       
    {
        $this->db->where('id', $id);
        $this->db->delete('peminjam');
    }

    public function getPeminjamById($id)
    {
        $joinpeminjam = "SELECT    a.id,
                                a.nama,
                                a.alamat,
                                a.no_hp,
                                a.id_barang,
                                b.barang,
                                a.keperluan
                                FROM peminjam AS a
                                JOIN barang AS b
                                ON a.id_barang = b.id
                                WHERE a.id = $id";
        return $query = $this->db->query($joinpeminjam)->row_array();
    }

    public function Caripeminjam()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('id', $keyword);
        $this->db->or_like('nama', $keyword);
        $this->db->or_like('alamat', $keyword);
        $this->db->or_like('no_hp', $keyword);
        $this->db->or_like('keperluan', $keyword);
        return $this->db->get('barang')->result_array();
    }
}